# TCM-QM property-summary table

`TCM-QM_property_summary_3196.csv` is a derived convenience table for searching, filtering and statistical analysis. It does not replace `tables/tcm_qm_master.csv`, the record-level TCMSP evidence table or the deduplicated herb-CID edge table.

## Table structure

- Each row represents one PubChem CID. The table contains 3,196 rows and no duplicate CIDs.
- The 56 columns comprise six identity or herb-annotation fields and 50 molecular-composition, quantum-chemical, thermochemical, dipole, rotational and vibrational fields.
- The file uses UTF-8 with a byte-order mark for direct use in spreadsheet software.
- Missing values are represented by empty fields rather than zero. The current 56-column table contains no missing values.

## First six columns

| Field | Definition |
|---|---|
| `cid` | PubChem Compound ID; treat as a text identifier. |
| `smiles` | The `pubchem_SMILES` value from the master table. It comes from PubChem and is not a bond-connectivity assignment inferred from the DFT coordinates. |
| `herbs` | Herb names associated with the CID; multiple values are separated by ` | `. |
| `herb_count` | Number of herb names in `herbs`. |
| `herb_4qi` | Four-qi annotations positionally aligned with `herbs`; multiple values are separated by ` | `. |
| `herb_guijing` | Meridian annotations positionally aligned with `herbs`; multiple values are separated by ` | `. |

For records associated with multiple herbs, split `herbs`, `herb_4qi` and `herb_guijing` on the pipe delimiter while preserving positional order. Use `tables/tcm_source_edges.csv` and `tables/tcm_source_provenance.csv` for relationship-level analysis, deduplication, evidence tracing or provenance adjudication. Do not treat the three pipe-delimited columns as independent sets.

## Quantum-chemical fields and units

- `_eh`: hartree.
- `_ev`: electronvolt.
- `_kcal_mol`: kcal mol⁻¹.
- `_cm1`: cm⁻¹.
- `_mhz`: MHz.
- `_au`: atomic units.
- `_debye`: Debye.
- `max_ir_intensity_km_mol`: km mol⁻¹.

See `tables/data_dictionary.csv` for complete field definitions, origins, data types, units and missing-value rules. Absolute electronic energies, enthalpies and Gibbs free energies should not be ranked directly across molecules with different elemental compositions. `homo_lumo_gap_ev` is a Kohn-Sham orbital-energy gap, not an experimental optical gap. Thermochemical quantities follow the reported 298.15 K, 1 atm and QRRHO conventions.

## Quality and interpretation boundaries

- All 3,196 calculations terminated normally and completed geometry optimization and frequency analysis.
- Of the 3,196 records, 3,191 have no imaginary frequency; five contain one minor negative mode with an absolute magnitude below 5 cm⁻¹. Analyses requiring strict local minima should filter for `imaginary_frequency_count=0`.
- The release provides one DFT-optimized conformer per CID. It is not a conformational ensemble and does not guarantee the global minimum-energy conformer.
- A net charge of zero does not imply the absence of formally charged atoms. Canonical PubChem SMILES for 38 net-neutral records contain both positive and negative formal charges: 14 use exclusively nitro-group resonance notation, whereas 24 represent other charge-separated microspecies. Analyses of dipoles, energies or machine-learning targets should join `tables/ionization_state_audit.csv` by CID and retain `charge_representation_class`.
- The reported values are gas-phase DFT results and should not be interpreted directly as solution-phase, solid-state, pharmacological or clinical properties.
- TCMSP herb associations represent source-database relationships; they do not establish abundance, bioavailability, activity or therapeutic efficacy.

## Completed consistency checks

- The 3,196 CIDs are unique and exactly match the CID set in the 87-field enhanced master table.
- All 51 shared fields agree with the enhanced master table on a per-CID basis.
- SMILES, herb names and herb counts agree with their respective source tables for every CID.
- Four-qi and meridian annotations were matched for all 495 herbs.
- Numerical closure checks passed for HOMO-LUMO differences, hartree/eV and hartree/kcal mol⁻¹ conversions, dipole magnitudes, rotational constants, thermal energy, enthalpy and Gibbs free energy.
- Frequency counts satisfy 3N-5 for linear molecules or 3N-6 for nonlinear molecules.
