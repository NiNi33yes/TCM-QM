# TCM-QM 1.1.0 provenance correction

Release candidate: `1.1.0-rc1`  
Prepared: 5 September 2026

## What changed

- Rebuilt TCMSP provenance from the complete molecule-page export and the retained herb-page snapshot.
- Reviewed all 382 relations present only in the historical graph and excluded all of them from the primary graph: 174 conflicting title-inferred CID relations, 111 unanchored legacy relations and 97 identity-confirmed relations whose page-level herb lists differ from the molecule-page export; all are retained in an audit ledger.
- Preserved all source-record evidence for the nine PubChem CIDs resolving from multiple TCMSP MOL_ID values; CID–herb graph summaries use their deduplicated union.
- Replaced the historical 6,557-edge graph with 16,918 accepted unique herb–CID edges supported by 16,930 evidence records, spanning 495 herbs and all 3,196 released CIDs.
- Added `tcm_qm_master_with_tcmsp.csv`, while preserving the stable 79-field one-row-per-CID quantum master table.
- Updated manuscript facts, website graph data, downloads and checksum manifests to the same adjudicated counts.

## What did not change

Quantum-chemical values, molecular identities after the previously documented repairs, optimized XYZ coordinates, candidate-selection decisions and the 3,196-file ORCA OUT archive are unchanged. The OUT companion archive retains SHA-256 `c24933581aa93112b64ebbe33768b8cd6c5bcd8ac509c5079bece87097ff08bf`.

## Citation warning

Version 1.0.0 (DOI `10.5281/zenodo.22173180`) is a historical snapshot and is superseded for TCMSP coverage and graph statistics. Cite the final 1.1.0 DOI once assigned.
