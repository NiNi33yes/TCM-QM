# Data dictionary audit

Audit scope: `tables/tcm_qm_master.csv`, `tables/data_dictionary.csv` and
`tables/schema.json` in provenance-corrected release candidate `1.1.0-rc1`.

## Structural checks

- Master-table records: 3,196.
- Master-table fields: 79.
- Data-dictionary rows: 79.
- Schema fields: 79.
- Missing or extra field definitions: 0.
- Duplicate field definitions: 0.
- Blank dictionary cells: 0.
- Field positions: contiguous 1-79.

## Clarifications added

- CID fields are typed as string identifiers rather than analytical integers.
- T*S energy terms are distinguished from entropy-per-kelvin quantities.
- Absolute electronic, enthalpy and Gibbs energies carry cross-stoichiometry warnings.
- HOMO-LUMO differences are identified as Kohn-Sham orbital-energy gaps, not
  experimental optical or quasiparticle gaps.
- Cartesian dipole components are marked orientation-dependent; dipole magnitudes are
  identified as gas-phase quantities.
- The strict positive-curvature subset rule is defined as
  `imaginary_frequency_count == 0`.
- Runtime is identified as hardware-, workload- and software-version dependent.
- PubChem annotations are distinguished from calculated quantum-chemical fields.

The CSV dictionary and JSON schema were regenerated from the same release generator after
these clarifications were added.
