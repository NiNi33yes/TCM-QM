# NIST CCCBDB dipole-moment validation

The frozen TCM-QM dipole magnitudes were matched to experimental gas-phase values from NIST CCCBDB (SRD 101, Release 22, May 2022; DOI 10.18434/T47C7Z) by CAS Registry Number and exact elemental composition. Of 65 candidate rows, 49 had a single usable reference. CID 5257127 was excluded before statistics because the TCM-QM/PubChem record is a zwitterion whereas the CCCBDB entry represents neutral gas-phase glycine, leaving 48 primary records.

The primary statistics always use the frozen release values. CID 1032 is retained in that analysis. A targeted two-conformer calculation established that its large frozen dipole is geometry-specific; the lower-energy conformer is used only in a separately labelled conformer-aware sensitivity analysis. The 47-record calculation excluding CID 1032 is diagnostic and is not the primary benchmark.
