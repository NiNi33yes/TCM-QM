# TCM-QM 3196-record selection audit

## Result

The selection chain is arithmetically closed and the final CID set exactly matches the 3,196 rows marked as copied in the adjudication master.

- Candidate calculation records: 6,948
- Normalized unique CIDs: 6,106
- Excluded for missing frequencies or SCF-only output: 2,860
- Excluded for significant imaginary frequencies: 63
- Excluded for unconverged optimization: 13
- Initially qualified records: 4,012
- Qualified duplicate records not selected: 816
- Final release records: 3,196

## Conservation equations

`6948 - 2860 - 63 - 13 = 4012`

`4012 - 816 = 3196`

## CID normalization

There are 843 original labels containing a herb-name prefix. Extracting the terminal numeric CID yields 6,106 normalized unique CIDs and 842 duplicate candidate rows.

## Set-level verification

- Final CIDs absent from copied records: 0
- Copied CIDs absent from the final table: 0
- Exact set match: True

The source CSV files were read only. Their SHA-256 digests are recorded in `selection_audit_summary.json`.
