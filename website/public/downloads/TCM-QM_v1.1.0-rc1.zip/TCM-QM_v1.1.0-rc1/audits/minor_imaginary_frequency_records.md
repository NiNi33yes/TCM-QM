# Minor negative-frequency records

Five of the 3,196 released calculations retain one negative vibrational frequency with
magnitude below 5 cm^-1. Values are reported exactly as parsed and are not rounded to
zero. The available audit does not include mode-vector inspection, so no torsional or
other mechanistic assignment is made.

| CID | Signed lowest frequency (cm^-1) | Imaginary-frequency count | Release treatment |
|---:|---:|---:|---|
| 7463 | -3.53 | 1 | `minor_negative_mode_retained` |
| 17355 | -3.60 | 1 | `minor_negative_mode_retained` |
| 62351 | -4.83 | 1 | `minor_negative_mode_retained` |
| 70214 | -2.27 | 1 | `minor_negative_mode_retained` |
| 86950 | -2.08 | 1 | `minor_negative_mode_retained` |

## Reuse rule

- Inclusive release: retain all 3,196 records and preserve the quality flag.
- Strict positive-curvature subset: filter to `imaginary_frequency_count == 0`, yielding
  3,191 records.
- Do not describe the five retained records as rigorously established local minima unless
  a future calculation or mode-vector inspection resolves the negative mode.
