# TCM-QM Supplementary Information

## Supplementary Table S1. Starting-geometry provenance records not assigned to the coordinate-identity-consistent class

This table lists all 38 records outside the `coordinate_identity_consistent` class in the frozen full-dataset starting-geometry audit. For 37 records, RMSD is the heavy-atom RMSD after optimal rigid-body alignment in the archived atom order. CID 10946210 required element-labelled heavy-atom graph-isomorphism mapping because the repaired ORCA input and PubChem3D reference used different atom orders; its reported value is the lowest RMSD across two valid mappings. The operational classes are quality-control bins and do not establish conformer identity or global-minimum status. This Markdown table is the canonical human-readable presentation; `Supplementary_Table_S1.csv` is its machine-readable companion and must contain the same 38 records and values.

| PubChem CID | ORCA version | Heavy atoms | RMSD (Å) | Final provenance classification | Comparison route |
|---:|:---:|---:|---:|:---|:---|
| 248 | 6.1.1 | 8 | 0.421491 | `same_or_similar_conformer` | Direct archived atom order |
| 5571 | 6.1.1 | 10 | 0.205801 | `same_or_similar_conformer` | Direct archived atom order |
| 13561 | 6.0.1 | 12 | 0.047512 | `same_geometry_with_minor_relaxation` | Direct archived atom order |
| 15109 | 6.0.1 | 13 | 0.047892 | `same_geometry_with_minor_relaxation` | Direct archived atom order |
| 16238 | 6.0.1 | 13 | 0.042374 | `same_geometry_with_minor_relaxation` | Direct archived atom order |
| 17355 | 6.0.1 | 11 | 0.045851 | `same_geometry_with_minor_relaxation` | Direct archived atom order |
| 18502 | 6.0.1 | 9 | 0.048755 | `same_geometry_with_minor_relaxation` | Direct archived atom order |
| 20970 | 6.0.1 | 5 | 0.038698 | `same_geometry_with_minor_relaxation` | Direct archived atom order |
| 31249 | 6.0.1 | 12 | 0.045878 | `same_geometry_with_minor_relaxation` | Direct archived atom order |
| 61235 | 6.0.1 | 10 | 0.048487 | `same_geometry_with_minor_relaxation` | Direct archived atom order |
| 62351 | 6.0.1 | 8 | 0.032829 | `same_geometry_with_minor_relaxation` | Direct archived atom order |
| 65057 | 6.0.1 | 16 | 0.045707 | `same_geometry_with_minor_relaxation` | Direct archived atom order |
| 68252 | 6.0.1 | 14 | 0.064440 | `same_geometry_with_minor_relaxation` | Direct archived atom order |
| 69421 | 6.0.1 | 18 | 0.047796 | `same_geometry_with_minor_relaxation` | Direct archived atom order |
| 69687 | 6.0.1 | 11 | 0.040712 | `same_geometry_with_minor_relaxation` | Direct archived atom order |
| 69867 | 6.0.1 | 12 | 0.048164 | `same_geometry_with_minor_relaxation` | Direct archived atom order |
| 73467 | 6.0.1 | 27 | 0.050823 | `same_geometry_with_minor_relaxation` | Direct archived atom order |
| 82140 | 6.0.1 | 6 | 0.053997 | `same_geometry_with_minor_relaxation` | Direct archived atom order |
| 89664 | 6.0.1 | 11 | 0.045503 | `same_geometry_with_minor_relaxation` | Direct archived atom order |
| 91520 | 6.0.1 | 25 | 0.069002 | `same_geometry_with_minor_relaxation` | Direct archived atom order |
| 97597 | 6.0.1 | 27 | 0.050425 | `same_geometry_with_minor_relaxation` | Direct archived atom order |
| 133534 | 6.1.1 | 33 | 0.056825 | `same_geometry_with_minor_relaxation` | Direct archived atom order |
| 136449 | 6.1.1 | 9 | 0.051872 | `same_geometry_with_minor_relaxation` | Direct archived atom order |
| 181215 | 6.0.1 | 18 | 0.050578 | `same_geometry_with_minor_relaxation` | Direct archived atom order |
| 442668 | 6.0.1 | 23 | 0.062420 | `same_geometry_with_minor_relaxation` | Direct archived atom order |
| 471114 | 6.1.1 | 32 | 0.060428 | `same_geometry_with_minor_relaxation` | Direct archived atom order |
| 480774 | 6.1.1 | 24 | 0.057340 | `same_geometry_with_minor_relaxation` | Direct archived atom order |
| 485077 | 6.0.1 | 26 | 0.057490 | `same_geometry_with_minor_relaxation` | Direct archived atom order |
| 519382 | 6.0.1 | 14 | 0.071493 | `same_geometry_with_minor_relaxation` | Direct archived atom order |
| 596567 | 6.1.1 | 15 | 0.052929 | `same_geometry_with_minor_relaxation` | Direct archived atom order |
| 618317 | 6.0.1 | 19 | 0.062109 | `same_geometry_with_minor_relaxation` | Direct archived atom order |
| 3702506 | 6.1.1 | 10 | 0.049040 | `same_geometry_with_minor_relaxation` | Direct archived atom order |
| 5281416 | 6.0.1 | 13 | 0.058971 | `same_geometry_with_minor_relaxation` | Direct archived atom order |
| 10779560 | 6.1.1 | 21 | 0.054370 | `same_geometry_with_minor_relaxation` | Direct archived atom order |
| 10932599 | 6.1.1 | 15 | 0.056728 | `same_geometry_with_minor_relaxation` | Direct archived atom order |
| 10946210 | 6.1.1 | 21 | 1.134342 | `separately_generated_stereochemical_repair_geometry` | Heavy-atom graph isomorphism (best of 2 mappings) |
| 12306866 | 6.1.1 | 20 | 0.056019 | `same_geometry_with_minor_relaxation` | Direct archived atom order |
| 14825644 | 6.0.1 | 22 | 0.058960 | `same_geometry_with_minor_relaxation` | Direct archived atom order |

**Class definitions.** `same_geometry_with_minor_relaxation`: RMSD > 0.02 Å and ≤ 0.20 Å. `same_or_similar_conformer`: RMSD > 0.20 Å within the predefined quality-control bin (the two observed values were 0.205801 and 0.421491 Å). `separately_generated_stereochemical_repair_geometry`: documented ETKDG/MMFF E/Z repair geometry, not direct PubChem3D coordinate reuse.

**Frozen evidence source.** `initial_geometry_pubchem3d_full_results_frozen.csv` (SHA-256: `6195f2472919ebe4e43e036003a9008684e6334d959d933cceee209041e1edab`). The CID 10946210 graph-mapping result is preserved separately in `10946210_graph_mapping_result.json`.

## Supplementary Table S2. Candidate-selection flow and exclusion accounting

The complete candidate ledger contains 6,948 calculation records corresponding to 6,106 normalized CIDs. Terminal-numeric CID normalization resolves 843 herb-prefixed labels and identifies 627 multi-record CID groups, comprising 842 candidate rows beyond the first record in each group. The mutually exclusive decision counts are:

| Decision stage | Records |
|---|---:|
| Candidate calculation records | 6,948 |
| Excluded: missing frequency result or SCF-only output | 2,860 |
| Excluded: significant imaginary frequency | 63 |
| Excluded: geometry optimization not converged | 13 |
| Initially qualified | 4,012 |
| Qualified duplicate candidate not selected | 816 |
| Final release records | 3,196 |

The two conservation equations are `6,948 − 2,860 − 63 − 13 = 4,012` and `4,012 − 816 = 3,196`. The normalized CID set of the 3,196 rows marked as copied is identical to the final-qualified table, with zero missing and zero additional CIDs. `tables/selection_decisions.csv` supplies the complete row-level decisions; `Supplementary_Table_S2_selection_flow.csv` is the compact machine-readable companion. Source-file hashes and executable checks are recorded in `audits/selection_audit_summary.json`.

## Supplementary Table S3. Identity and stereochemical repairs

Three records were recomputed or replaced during identity auditing. CIDs 248 and 5571 were corrected to formal charge +1 and singlet multiplicity, consistent with their PubChem identities. CID 10946210 underwent an E/Z stereochemical repair; its starting geometry was generated separately with ETKDG/MMFF and therefore is not claimed as direct PubChem3D coordinate reuse. All three repaired calculations converged, contain complete frequency results and terminated normally. The machine-readable record is `Supplementary_Table_S3_repairs.csv`. Corrected release values are addressable by CID in `tables/tcm_qm_master.csv`, and the exact replacement OUT objects are identified in `manifests/orca_out_3196_manifest.csv`; the graph-mapping result for CID 10946210 is retained in `audits/10946210_graph_mapping_result.json`.

## Supplementary Table S4. Final warning adjudication for CID 126312

CID 126312 was retained after an event-order audit of its unusually warning-rich ORCA output. The file contains 732 trust-region diagnostics, 860 intermediate `Not converged` messages, 437 internal-coordinate step failures with Cartesian fallback and seven transient MPI/Libfabric errors. These events do not represent the terminal state: the last intermediate non-convergence and internal-coordinate failures occur at lines 557348 and 557351, final optimization convergence is recorded at line 557382, the frequency section begins at line 558421, and normal termination occurs at line 561943. All 129 expected frequencies are present, no negative frequency is present, and the total runtime is 22 h 30 min 48.651 s. The retained quality class is `retain_with_recovered_optimization_and_transient_mpi_warnings`. Machine-readable event counts are supplied in `Supplementary_Table_S4_warning_adjudication.csv`; full evidence is preserved in `audits/final_adjudication_126312.json`, `audits/final_retention_audit_126312.json` and `audits/warning_audit_126312.json`.

## Supplementary Table S5. Net-neutral records with internal formal-charge separation

The 38 records below have calculation net charge zero and canonical PubChem SMILES containing both positive and negative formal charges. The classification separates canonical nitro-group resonance notation from other charge-separated microspecies. This is a representation and identity audit, not evidence that a calculated value is incorrect. The full record-level table is supplied as `Supplementary_Table_S5_ionization_state.csv`.

| PubChem CID | PubChem title | Representation class | Dipole magnitude (D) |
|---:|---|---|---:|
| 980 | 4-Nitrophenol | Nitro resonance notation | 5.390 |
| 1941 | 9-Hydroxy-8-Methoxy-6-Nitro-Phenanthrol(3,4-D)(1,3)Dioxole-5-Carboxylic Acid | Nitro resonance notation | 10.191 |
| 2236 | Aristolochic Acid | Nitro resonance notation | 8.503 |
| 6753 | Musk ambrette | Nitro resonance notation | 4.282 |
| 11087 | 2-Nitrobenzoic acid | Nitro resonance notation | 6.831 |
| 28782 | Protonated arginine | Other charge-separated microspecies | 5.112 |
| 108168 | Aristolochic Acid Ii | Nitro resonance notation | 8.802 |
| 128576 | Aristoloside | Nitro resonance notation | 9.540 |
| 147113 | aristolochic acid E | Nitro resonance notation | 11.497 |
| 161218 | Aristolochic acid-D | Nitro resonance notation | 8.798 |
| 165274 | Aristolochic Acid C | Nitro resonance notation | 9.167 |
| 167493 | Aristolochic Acid Iv | Nitro resonance notation | 9.599 |
| 449023 | p-Nitrophenyl alpha-D-mannopyranoside | Nitro resonance notation | 7.498 |
| 557916 | 2,6-Dimethyl-6-nitro-2-hepten-4-one | Nitro resonance notation | 4.934 |
| 3702506 | 4-Oxoniobenzoate | Other charge-separated microspecies | 20.728 |
| 5257127 | alpha-Glycine | Other charge-separated microspecies | 5.619 |
| 6857581 | d,l-Serine | Other charge-separated microspecies | 5.036 |
| 6923516 | (2S)-2-ammonio-3-(1H-indol-3-yl)propanoate | Other charge-separated microspecies | 3.214 |
| 6923517 | (2R)-2-ammonio-3-(1H-indol-3-yl)propanoate | Other charge-separated microspecies | 3.218 |
| 6925665 | Endorphenyl | Other charge-separated microspecies | 4.795 |
| 6942100 | (2S)-2-ammonio-3-(4-hydroxyphenyl)propanoate | Other charge-separated microspecies | 5.658 |
| 6971009 | (2S)-2-ammonio-3-(1H-imidazol-4-yl)propanoate | Other charge-separated microspecies | 5.204 |
| 6971018 | 2-Aminoisovaleric acid | Other charge-separated microspecies | 5.260 |
| 6971019 | (2S,3R)-2-ammonio-3-hydroxybutanoate | Other charge-separated microspecies | 4.245 |
| 6971047 | (2S)-pyrrolidinium-2-carboxylate | Other charge-separated microspecies | 5.782 |
| 6971195 | CID 6971195 | Other charge-separated microspecies | 16.483 |
| 6992087 | (2S)-2-ammonio-4-(methylsulfanyl)butanoate | Other charge-separated microspecies | 4.886 |
| 7043901 | (2S,3S)-2-ammonio-3-methylpentanoate | Other charge-separated microspecies | 5.224 |
| 7045798 | Leucine zwitterion | Other charge-separated microspecies | 4.941 |
| 7059534 | CID 7059534 | Other charge-separated microspecies | 17.417 |
| 7311724 | (2S)-2-ammoniopropanoate | Other charge-separated microspecies | 5.429 |
| 40468028 | CID 40468028 | Other charge-separated microspecies | 16.025 |
| 44272391 | CID 44272391 | Other charge-separated microspecies | 6.300 |
| 44367445 | CID 44367445 | Other charge-separated microspecies | 3.413 |
| 45359754 | Thalictricoside | Nitro resonance notation | 4.951 |
| 46224610 | (2S)-2-ammonio-4-(carbamimidamidooxy)butanoate | Other charge-separated microspecies | 5.338 |
| 51380903 | (2R)-2-azaniumyl-3-[(S)-prop-2-ene-1-sulfinyl]propanoate | Other charge-separated microspecies | 5.439 |
| 59098743 | Not supplied | Other charge-separated microspecies | 14.496 |

## Supplementary Table S6. Targeted conformer-sensitivity audit for CID 1032

CID 1032 (propanoic acid) was examined after its frozen dipole magnitude appeared as an external-comparison outlier. A 6.1.1 single-point calculation on the frozen optimized geometry reproduced the released dipole and differed from the frozen 6.0.1 electronic energy by only 0.0031 kcal mol⁻¹, excluding parser error and showing that the electronic-energy version contribution is negligible here. Rotation of the carboxyl O=C–O–H torsion followed by full optimization and frequency analysis located a lower-energy local minimum. At 6.1.1 the paired electronic-energy difference is 5.0566 kcal mol⁻¹. The 4.8857 kcal mol⁻¹ Gibbs difference derives from optimized/frequency outputs from different ORCA versions and is therefore supportive rather than strictly version-paired. Both optimized conformers have zero imaginary frequencies. The frozen value remains in the master table because the release records the documented single-starting-geometry result; the second conformer quantifies sensitivity and is not a post hoc replacement.

| Record | ORCA version | Electronic energy (Eh) | Gibbs free energy (Eh) | Dipole magnitude (D) | Relative E (kcal mol⁻¹) | Relative G (kcal mol⁻¹) | Imaginary frequencies |
|---|---:|---:|---:|---:|---:|---:|---:|
| Frozen release conformer | 6.0.1 | -268.373852374127 | -268.31272846 | 4.281846123 | 5.0597 | 4.8857 | 0 |
| Frozen geometry, independent single point | 6.1.1 | -268.373857273265 | NA | 4.282050039 | 5.0566 | NA | NA |
| Carboxyl-rotated, reoptimized conformer | 6.1.1 | -268.381915458106 | -268.32051430 | 1.600864102 | 0.0000 | 0.0000 | 0 |

Machine-readable values are provided in `Supplementary_Table_S6_cid1032_conformer_sensitivity.csv`. Inputs, complete ORCA outputs and the adjudication JSON are retained in `audits/cid1032_conformer_sensitivity/`.

## Supplementary Table S7. NIST CCCBDB experimental dipole-moment validation

TCM-QM identities were matched to NIST CCCBDB gas-phase experimental dipole moments by CAS Registry Number and exact elemental composition. Of 65 candidate rows, 49 had a unique single-reference match. CID 5257127 was excluded before statistical analysis because the TCM-QM/PubChem record represents zwitterionic glycine whereas the CCCBDB record represents neutral gas-phase glycine. The resulting 48-record primary benchmark retains every frozen release value, including CID 1032.

| Analysis | n | MAE (D) | RMSE (D) | Median AE (D) | Pearson r | Spearman ρ | AE ≤ 0.20 D |
|---|---:|---:|---:|---:|---:|---:|---:|
| Frozen release, primary | 48 | 0.1497 | 0.3915 | 0.0675 | 0.9546 | 0.9793 | 40 |
| Frozen release, CID 1032 excluded (diagnostic) | 47 | 0.0990 | 0.1418 | 0.0665 | 0.9952 | 0.9937 | 40 |
| Conformer-aware sensitivity, CID 1032 retained | 48 | 0.1000 | 0.1420 | 0.0675 | 0.9949 | 0.9901 | 41 |

The conformer-aware analysis substitutes the independently optimized lower-energy value of 1.600864102 D only for CID 1032; it does not alter the frozen master table. The complete 49-row matching ledger, including the pre-statistical exclusion and record-level references, is supplied as `Supplementary_Table_S7_nist_cccbdb_dipole_validation.csv`. Source snapshots, candidate tables and machine-readable summary statistics are preserved in `audits/nist_cccbdb_dipole_validation/`.
