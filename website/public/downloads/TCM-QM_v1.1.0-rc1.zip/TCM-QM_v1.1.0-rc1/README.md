# TCM-QM — a TCMSP-linked quantum-chemical collection of 3,196 PubChem-indexed compounds

Provenance-corrected candidate: 2026-09-05 (Asia/Shanghai)

## Scope and frozen facts

- 3,196 unique PubChem CIDs and 3,196 unique full InChIKeys.
- All records terminated normally and passed geometry-optimization convergence checks.
- 3,191 records have no imaginary frequency; five have a single minor negative mode between −4.83 and −2.08 cm⁻¹ and remain explicitly flagged.
- Quantum chemistry level: B3LYP-D3BJ/def2-TZVP, gas phase, 298.15 K and 1 atm, QRRHO reference frequency 100 cm⁻¹.
- ORCA versions: 6.0.1 (2,407 records), 6.1.1 (789 records).

## 1. Source provenance and inclusion flow

Two locally materialized TCMSP snapshots provide 16,930 accepted herb–compound evidence rows, corresponding to 16,918 adjudicated unique edges and covering all 3,196 final CIDs and 495 unique herbs. All 16,918 edges are direct MOL_ID–CID–herb relations from the complete molecule-page CSV generated on 18 July 2025. The release retains evidence tier, source locator, snapshot and adjudication status for every accepted provenance row.

The conflict ledger records all 382 legacy-only relations from the earlier herb-page snapshot, and all are excluded from the primary graph: 174 title-inferred CID conflicts, 111 relations without a direct MOL_ID-to-CID anchor, and 97 identity-confirmed relations whose page-level herb lists differ from the molecule-page export. Nine CIDs associated with multiple TCMSP MOL_IDs retain every source record; CID-level herb sets use the deduplicated union. These rules are documented in `TCMSP_PROVENANCE_RULES.md`.

The selection ledger starts with 6,948 candidate calculation records representing 6,106 normalized CIDs; a CID can have more than one candidate calculation. It records 2,860 exclusions for missing frequency/full optimization evidence, 63 for significant imaginary frequencies, and 13 for non-convergence. Of 4,012 initially qualified records, 816 were not selected during grouped deduplication/summary assembly, leaving exactly 3,196 final CIDs. The selected CID set is identical across the judgment ledger, final-qualified table, and frozen master table.

## 2. ORCA-version batch analysis

For each selected descriptor, an OLS model with HC3 robust standard errors was fitted. The contrast is ORCA 6.1.1 minus 6.0.1, while controlling for standardized elemental counts parsed from each molecular formula. P-values were corrected across the tested descriptors using Benjamini–Hochberg FDR. This is an association analysis, not a causal software-version experiment, because version assignment was not randomized.

- FDR-significant descriptors: final_electronic_energy_eh, homo_ev, homo_lumo_gap_ev, dipole_magnitude_debye, zpe_kcal_mol, final_gibbs_free_energy_eh, lowest_positive_frequency_cm1, highest_frequency_cm1, max_ir_intensity_km_mol, runtime_seconds.
- Descriptors with |adjusted standardized beta| ≥ 0.10: dipole_magnitude_debye, highest_frequency_cm1, runtime_seconds.

The complete coefficients, HC3 uncertainty intervals, raw mean differences, and FDR values are in `tables/orca_version_composition_adjusted_analysis.csv`.

## 3. Ionization-state representation audit

Net charge alone does not distinguish structures whose canonical SMILES contain internal positive and negative formal charges. `tables/ionization_state_audit.csv` therefore reports charged-atom counts and a representation class for all 3,196 CIDs. Among the 3,194 net-neutral calculations, 38 canonical PubChem SMILES contain both positive and negative formal charges. Fourteen are explained exclusively by canonical nitro-group resonance notation; 24 represent other charge-separated microspecies that require explicit attention in dipole, energy and modelling analyses. These records are not classified as calculation errors solely from SMILES notation. The record-level subset is provided as `Supplementary_Table_S5_ionization_state.csv`.

## 4. Targeted conformer-sensitivity audit

CID 1032 was examined because its frozen dipole magnitude was an external-comparison outlier. A 6.1.1 single-point calculation on the frozen optimized geometry reproduced the released value (4.282050 versus 4.281846 D), excluding parser or transcription error, and its electronic energy differed from the frozen 6.0.1 value by only 0.0031 kcal mol⁻¹. Rotation of the carboxyl O=C–O–H torsion followed by full B3LYP-D3BJ/def2-TZVP optimization and frequency analysis produced a second zero-imaginary-frequency local minimum with a dipole magnitude of 1.600864 D. At 6.1.1, the paired electronic-energy difference is 5.0566 kcal mol⁻¹. The 4.8857 kcal mol⁻¹ Gibbs difference derives from optimized/frequency outputs from different versions and is retained only as supportive evidence. The frozen master-table value remains the protocol-consistent single-conformer result; the complete sensitivity evidence is stored in `audits/cid1032_conformer_sensitivity/` and `Supplementary_Table_S6_cid1032_conformer_sensitivity.csv`.

## 5. NIST CCCBDB dipole validation

Forty-eight pre-specified TCM-QM records were compared with experimental gas-phase dipole moments from NIST CCCBDB (SRD 101, Release 22, May 2022; DOI `10.18434/T47C7Z`). The frozen primary benchmark gives MAE 0.1497 D, RMSE 0.3915 D, Pearson r 0.9546 and Spearman rho 0.9793. The largest residual, CID 1032, was resolved as conformer-sensitive rather than a parser error. A separately labelled conformer-aware sensitivity analysis retains n=48 and gives MAE 0.1000 D, RMSE 0.1420 D and Pearson r 0.9949; it does not alter the frozen master table. The complete matching ledger is `Supplementary_Table_S7_nist_cccbdb_dipole_validation.csv`, with source snapshots and machine-readable statistics in `audits/nist_cccbdb_dipole_validation/`.

## 6. Numerical closure

Twelve executable checks cover orbital gaps, Hartree/eV and Hartree/kcal conversions, component sums, and thermal/enthalpy/Gibbs identities. Tolerances are declared per equation and are chosen to accommodate the printed precision of the ORCA-derived CSV. Total failing row–check pairs: 0. See `tables/numerical_closure_summary.csv` and `tables/numerical_closure_failures.csv`.

## 7. Frozen package

- Master records: 3,196
- XYZ structures: 3,196 DFT-optimized coordinates
- Machine-learning benchmark files copied: 15
- Every payload file is listed with byte size and SHA-256 in `manifests/files_sha256.csv`.
- `tables/data_dictionary.csv` and `tables/schema.json` define all 79 master-table fields, units, origins and missing-value rules.

The package-level `TCM-QM_property_summary_3196.csv` is a 56-column derived convenience table for filtering and exploratory analysis. It combines PubChem SMILES, pipe-delimited herb names, positionally aligned four-qi and meridian annotations, and 50 selected molecular and quantum-chemical fields. It does not replace the 79-field master table or the normalized provenance tables. Its companion README defines delimiter handling, units and scientific-use limitations.

## Structure recovery audit

The earlier local assembly temporarily used 154 ETKDG/MMFF placeholders because those optimized coordinate files were absent from the first local structure directory. The corresponding 154 ORCA outputs were subsequently recovered. All 154 terminate normally, contain converged optimizations, frequency sections and final Cartesian-coordinate sections. Their DFT-optimized coordinates replace the placeholders in this v5 freeze. CID 10946210 uses the later E/Z stereochemistry-corrected recalculation.

## Release boundary

This package freezes the locally available publication data and validation artifacts. Raw ORCA OUT/GBW files are not included in this structured core archive. A complete companion archive of all 3,196 ORCA OUT files has been assembled and checksum-verified with zero unresolved CIDs. The archive is 1,272,690,614 bytes and has SHA-256 digest `c24933581aa93112b64ebbe33768b8cd6c5bcd8ac509c5079bece87097ff08bf`; its per-file manifest contains 3,196 data rows. It is intended for deposition alongside the structured release. GBW files are not part of version 1.1.0. The selected data licence is CC BY 4.0 for original release content, custom project code is licensed under MIT, and third-party material retains its source terms as described in `THIRD_PARTY_NOTICES.md`. A Zenodo DOI, final author list and public repository URL remain pending and are not fabricated here.
