# TCM-QM v1.1.0 provenance update

The 79-field quantum/identity master table and 3,196 optimized structures are unchanged. The TCMSP layer was rebuilt from the complete locally materialized molecule-page snapshot and adjudicated against the earlier herb-page snapshot. The release contains 16,918 unique accepted herb–CID edges across 495 herbs and all 3,196 CIDs. See `TCMSP_PROVENANCE_RULES.md` and the audit ledgers before reuse.
