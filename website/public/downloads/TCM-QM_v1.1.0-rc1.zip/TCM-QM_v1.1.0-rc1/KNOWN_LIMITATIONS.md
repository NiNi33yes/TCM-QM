# Known limitations and open pre-deposition checks

- All 3,196 CIDs have at least one accepted TCMSP source relation in the two documented
  local snapshots. This is snapshot coverage, not an exhaustive census of TCM chemical
  space and not evidence of abundance, exposure, activity, efficacy or clinical relevance.
- All 16,918 accepted unique edges are direct MOL_ID-CID-herb relations from the complete
  molecule-page snapshot. All 382 legacy-only herb-page assertions are excluded from the
  primary graph and retained only in the adjudication ledger: 174 title-inferred CID
  conflicts, 111 relations without a direct MOL_ID-to-CID anchor and 97 identity-confirmed
  relations whose herb-page lists differ from the molecule-page snapshot.
- Each CID represents one optimized gas-phase structure, not a conformer ensemble or a
  physiological protonation/solvation model.
- Five records retain one minor negative vibrational frequency and are explicitly flagged.
- `warning_count` is a count of warning-message occurrences, not unique warning types. CID
  126312 has 732 occurrences of one trust-region warning. Record-level review confirmed
  final geometry convergence, a complete 129-mode (3N-6) frequency analysis without an
  imaginary mode, and normal termination after transient MPI messages. It is retained as
  `retain_with_recovered_optimization_and_transient_mpi_warnings`; the three adjudication
  JSON files are in `audits/`.
- ORCA 6.0.1 and 6.1.1 are both present. The included regression is a batch-sensitivity
  analysis, not a same-molecule causal comparison. A paired cross-version recalculation
  was not performed; the release therefore does not claim numerical interchangeability
  or provide a correction between versions.
- Raw ORCA OUT/GBW files are not in this local structured candidate package. A complete
  3,196-file OUT companion archive has been assembled and checksum-verified on the
  staging server, but it still requires transfer and repository deposition. GBW scope
  remains subject to size and redistribution review. A clean end-to-end rebuild record
  from the deposited OUT archive also remains outstanding.
- The public DOI for provenance-corrected version 1.1.0 remains intentionally unset. The
  historical version 1.0.0 DOI must not be cited for the revised TCMSP coverage statistics.
