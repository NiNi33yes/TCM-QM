# Third-party data and software notices

TCM-QM combines original quantum-chemical calculations and derived audit tables with identifiers and metadata obtained from third-party resources. The CC BY 4.0 licence in `LICENSE_DATA_CC_BY_4.0.txt` applies only to material for which the dataset creators hold the necessary rights. It does not replace or expand the terms of the resources listed below.

## PubChem

PubChem CIDs, names, molecular formulae, SMILES, InChI, InChIKey and selected physicochemical annotations were retrieved from PubChem. PubChem records may incorporate contributions from multiple depositors. Users should retain PubChem attribution and consult the current PubChem documentation and usage policies when redistributing source metadata.

- Resource: https://pubchem.ncbi.nlm.nih.gov/
- Programmatic interface: https://pubchem.ncbi.nlm.nih.gov/docs/pug-rest

## TCMSP

Herb-compound source relations were reconstructed from locally materialized TCMSP research snapshots. These relations are source assertions and do not establish abundance, biological activity, efficacy or clinical relevance. TCMSP-derived identifiers, labels and source relations remain subject to the rights and terms applicable to the source database. The TCM-QM licence does not grant additional rights in TCMSP content.

- Resource: https://tcmsp-e.com/
- Dataset article: Ru, J. et al. TCMSP: a database of systems pharmacology for drug discovery from herbal medicines. *Journal of Cheminformatics* 6, 13 (2014). https://doi.org/10.1186/1758-2946-6-13

## NIST CCCBDB

The external dipole-moment audit cites experimental gas-phase values and preserves source-page snapshots from the NIST Computational Chemistry Comparison and Benchmark Database, Standard Reference Database 101, Release 22 (May 2022). Users should cite the database and follow applicable NIST terms for any reused source content.

- Resource: https://cccbdb.nist.gov/
- DOI: https://doi.org/10.18434/T47C7Z

## ORCA

ORCA output text is included as computational provenance. ORCA software binaries are not redistributed. Access to ORCA and any new calculations are governed by the ORCA licence and distribution terms.

- Resource: https://www.faccts.de/orca/

## Project code

Custom scripts included under `code/` are licensed separately under the MIT License in `code/LICENSE_MIT.txt`. Third-party Python packages remain under their own licences.

## Responsibility before public deposition

Before public deposition, the corresponding author and institution should confirm that the intended repository files and selected licence are compatible with the applicable third-party terms, particularly for the locally materialized TCMSP snapshots and cached source pages.
